const mongoose=require("mongoose");

const orderSchema=mongoose.Schema({

    productId:{
        type:mongoose.SchemaTypes.ObjectId,
        require:true
    },

    customerId:{
        type:mongoose.SchemaTypes.ObjectId,
        require:true
    },
    initialDate:{
        type:Date,
        require:true
    },
    deliveryDate:{
        type:Date,
        require:true
    },

    
});

const Order=mongoose.model("order",orderSchema);
module.exports=Order;

