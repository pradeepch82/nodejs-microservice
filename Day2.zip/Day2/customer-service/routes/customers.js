const { request } = require('express');
var express = require('express');
var mongoose= require("../db/db");

var Customer=require("../model/customer");
var router = express.Router();


router.get('/', function(request, response, next) {
  
  Customer.find()
           .then(result=>{
              response.json(result);     
            }).catch((err)=>{
                response.status(500).send("Internal Server error "+err);
            });

});


router.get('/:id', function(request, response, next) {
  let id=request.params.id;

  Customer.findById(id)
  .then(result=>{
     response.json(result);     
   }).catch((err)=>{
       response.status(404).send("Customer Not Found "+err);
   });
  

});

router.put('/:id', function(request, response, next) {
  let id=request.params.id;
  let customer=request.body;

  
  Customer.findByIdAndUpdate(id,customer)
  .then(result=>{
     response.status(200).send("Customer  with Id ["+id+"] updated successfuly");   
   }).catch((err)=>{
       response.status(404).send("Customer Not Found "+err);
   });


});

router.delete('/:id', function(request, response, next) {
  let id=request.params.id;
  
  Customer.findByIdAndDelete(id)
   .then(result=>{
     response.status(200).send("Customer  with Id ["+id+"] deleted successfuly");   
   }).catch((err)=>{
       response.status(404).send("Customer Not Found "+err);
   });

});

router.post('/', function(request, response, next) {
  
  let customer=request.body;
    const c=new Customer(customer);
console.log("In post :",customer);
    c.save().then(result=>{
       response.status(201).json(customer);   
     }).catch((err)=>{
         response.status(500).send("Internal Server Error "+err);
     });

});


module.exports = router;
