const express = require("express");
const mongoose = require("./db/db");
const Product = require("./model/product");
const Eureka =require("eureka-js-client").Eureka; 


const port = 3000;
const appName="product-service";
const eurekaHost='127.0.0.1';
const eurekaPort=8761;
const hostName="localhost";
const ipAddr="127.0.0.1";

//create a server
var app = express();
//to read data 
app.use(express.json());

app.get("/", (request, response) => response.send("Product Service runnig at " + port));

app.get("/products", (request, response) => {
    Product.find()
           .then(result=>{
              response.json(result);     
            }).catch((err)=>{
                response.status(500).send("Internal Server error "+err);
            });
});


app.get("/products/:id", (request, response) => {
    let id=request.params.id;

    Product.findById(id)
    .then(result=>{
       response.json(result);     
     }).catch((err)=>{
         response.status(404).send("Book Not Found "+err);
     });

});

app.put("/products/:id", (request, response) => {
    let id=request.params.id;
    let product=request.body;

    Product.findByIdAndUpdate(id,product)
    .then(result=>{
       response.status(200).send("Product with Id ["+id+"] updated successfuly");   
     }).catch((err)=>{
         response.status(404).send("Book Not Found "+err);
     });

});

app.delete("/products/:id", (request, response) => {
    let id=request.params.id;
   
    Product.findByIdAndDelete(id)
    .then(result=>{
       response.status(200).send("Product with Id ["+id+"] deleted successfuly");   
     }).catch((err)=>{
         response.status(404).send("Book Not Found "+err);
     });

});

app.post("/products", (request, response) => {
    let product=request.body;
    const p=new Product(product);

    p.save().then(result=>{
       response.status(201).json(product);   
     }).catch((err)=>{
         response.status(500).send("Internal Server Error "+err);
     });
});




//start the server
app.listen(port, () => console.log("Product Service started on port " + port))

const client = new Eureka({
    instance: {
      id: appName,    
      instanceId: `${appName}:${port}`,
      app: appName,
      hostName: hostName,
      ipAddr: ipAddr,
      statusPageUrl: `http://localhost:${port}`,
      port: {
        '$': port,
        '@enabled': 'true',
      },
      vipAddress: 'appName:'+port,
      dataCenterInfo: {
        '@class': 'com.netflix.appinfo.InstanceInfo$DefaultDataCenterInfo',
        name: 'MyOwn',
      }
    },
    eureka: {
      host: hostName,
      port: eurekaPort,
      servicePath: '/eureka/apps/'
    }
  });



  client.logger.level('debug')

  client.start( error => {
    console.log(error || appName+" registered")
  });
  
  
  
  function exitHandler(options, exitCode) {
    if (options.cleanup) {
    }
    if (exitCode || exitCode === 0) console.log(exitCode);
    if (options.exit) {
        client.stop();
    }
  }
  
  client.on('deregistered', () => {
    process.exit();
    console.log(appName+'after deregistered');
  })
  
  client.on('started', () => {
  console.log("eureka host  " + eurekaHost);
  })
  
  process.on('SIGINT', exitHandler.bind(null, {exit:true}));