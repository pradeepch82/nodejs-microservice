const { default: axios } = require('axios');
const { request } = require('express');
var express = require('express');
var mongoose= require("../db/db");
var Order=require("../model/order");
var router = express.Router();

router.get('/', function(request, response, next) {
  
  Order.find()
           .then(result=>{
           
              response.json(result);     
            }).catch((err)=>{
                response.status(500).send("Internal Server error "+err);
            });

});


router.get('/:id', function(request, response, next) {
  let id=request.params.id;
  let productService="http://localhost:3000/products";
  let customerService="http://localhost:3001/customers";
  
  
  let result={
    "_id":"",
    "productId":"",
    "customerId":"",
    "customer":{},
    "product":{},
    "initialDate":"",
    "deliveryDate":"",
    };





  Order.findById(id)
  .then(order=>{

    result._id=order._id;
    result.productId=order.productId;
    result.customerId=order.customerId;
    result.initialDate=order.initialDate;
    result.deliveryDate=order.deliveryDate;
         
      axios.get(customerService+"/"+order.customerId).then(customer=>{
        console.log("customer Details :",customer.data);

        result.customer=customer.data;

        axios.get(productService+"/"+order.productId).then(product=>{
          console.log("product Details :",product.data);
          
          result.product=product.data;
          response.json(result);  
        }).catch(err=>console.log("Customer Service Error :",err))
    
      }).catch(err=>console.log("Customer Service Error :",err))
    
    }).catch((err)=>{
       response.status(404).send("Customer Not Found "+err);
   });
  

});

router.post('/', function(request, response, next) {
  
  let order=request.body;
    const o=new Order(order);
    console.log("In post :",order);

    o.save().then(result=>{

      let customerService="http://localhost:3001/customers";
      axios.get(customerService+"/"+order.customerId).then(customer=>{
        
 //send a message to queue -store-app-queue
let message="Hello  "+customer.data.name+" !!! Your Order  is placed successfully";
var q = 'store-app-queue';

var open = require('amqplib').connect('amqp://localhost');


// Publisher
open.then(function(conn) {
  return conn.createChannel();
}).then(function(ch) {
  return ch.assertQueue(q).then(function(ok) {
    console.log("sending message to queue");
    return ch.sendToQueue(q, Buffer.from(message));
  });
}).catch(console.warn);
        
   
  response.status(201).json(o);   
     }).catch((err)=>{
         response.status(500).send("Internal Server Error "+err);
     });

});

});


module.exports = router;
