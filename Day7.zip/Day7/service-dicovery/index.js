var Resilient=require("resilient");
var eurekaMiddleWare=require("resilient-eureka");


const client=Resilient();

const servers=["http://localhost:8761"];


client.use(eurekaMiddleWare({
serviceName:"/eureka/apps/",
}));

client.setServers(servers);
client.discoverServers(servers);

client.get("/",(err,res)=>{
console.log(err);
if(res.status===200)
console.log("Response :",res.body);

});



