var seneca = require('seneca')();

seneca  
  //.use('basic')
  .use("entity")
  .use('mongo-store', {
      uri: 'mongodb://127.0.0.1:27017/company'
  })

seneca.add({"role": "product", "cmd": "create"}, (args, done) => {  
  var product = seneca.make$("Product");
  product.name = args.name;
  product.description = args.description;
  product.price = args.price;
  product.save$((err, savedProduct) => {
    console.log("In save  ,,,",savedProduct);
    done(err, savedProduct);
  });
});

// Listen for messages in the specified transport type and port.
seneca.listen({  
    "type": "http", 
    "port": 8888
});
/*
curl -d \
  '{"role":"product","cmd":"create","name":"Star Wars Jacket","price":100.00,"description":"Awesome!"}' \
    http://localhost:8080/act

    */



    //https://www.compose.com/articles/building-javascript-microservices-with-senecajs-and-compose/
    