var seneca = require('seneca')(); 

seneca.add({"role": "compose", "cmd": "ping"}, (args, done) => {  
    console.log(args);
    done(null, {result: "Hi there"});
});

seneca.listen({"type": "http", "port": 8080});  


//curl -d '{"role":"compose","cmd":"ping"}' http://localhost:8080/act
