const express = require("express");
const mongoose = require("./db/db");
const Product = require("./model/product");
const PORT = 3000;

//create a server
var app = express();
//to read data 
app.use(express.json());

app.get("/", (request, response) => response.send("Product Service runnig at " + PORT));

app.get("/products", (request, response) => {
    Product.find()
           .then(result=>{
              response.json(result);     
            }).catch((err)=>{
                response.status(500).send("Internal Server error "+err);
            });
});


app.get("/products/:id", (request, response) => {
    let id=request.params.id;

    Product.findById(id)
    .then(result=>{
       response.json(result);     
     }).catch((err)=>{
         response.status(404).send("Book Not Found "+err);
     });

});

app.put("/products/:id", (request, response) => {
    let id=request.params.id;
    let product=request.body;

    Product.findByIdAndUpdate(id,product)
    .then(result=>{
       response.status(200).send("Product with Id ["+id+"] updated successfuly");   
     }).catch((err)=>{
         response.status(404).send("Book Not Found "+err);
     });

});

app.delete("/products/:id", (request, response) => {
    let id=request.params.id;
   
    Product.findByIdAndDelete(id)
    .then(result=>{
       response.status(200).send("Product with Id ["+id+"] deleted successfuly");   
     }).catch((err)=>{
         response.status(404).send("Book Not Found "+err);
     });

});

app.post("/products", (request, response) => {
    let product=request.body;
    const p=new Product(product);

    p.save().then(result=>{
       response.status(201).json(product);   
     }).catch((err)=>{
         response.status(500).send("Internal Server Error "+err);
     });
});


//start the server
app.listen(PORT, () => console.log("Product Service started on port " + PORT))


