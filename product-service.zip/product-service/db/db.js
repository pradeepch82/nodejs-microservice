const dotenv = require('dotenv');
dotenv.config();
const mongoose = require('mongoose');
const mongoURI=process.env.MONGO_URI;
// Connect

mongoose.connect(mongoURI, { 
     useNewUrlParser: true,
     useUnifiedTopology: true,
}).then(() => {
     console.log('MongoDB Connection successful!');
}).catch((e) => {
     console.log(e);
     console.log('MongoDB Connection failed!');
})

exports=mongoose;