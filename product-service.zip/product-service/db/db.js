const mongoose=require("mongoose");
const mongoURL="mongodb://localhost:27017/mphasis_store_db";
mongoose.connect(mongoURL).then(()=>console.log("MongoDB connection successfull"))
                          .catch(()=>console.log("MongoDB connection failed"));

exports=mongoose;
                          

