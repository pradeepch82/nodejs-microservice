var express = require('express');
var router = express.Router();
var mongoose = require("../db/db")
const Product = require("../model/product");


router.post('/', (req, res) => {
  const product = new Product({ ...req.body });
  product.save().then(() => {
    res.status(201).json(product)
  }).catch((err) => {
    console.log(err);

    res.status(500).send('Internal Server Error!');
  })
})

router.get('/', (req, res) => {
  Product.find().then((products) => {
    if (products.length !== 0) {
      res.json(products)
    } else {
      res.status(404).send('Products not found');
    }
  }).catch((err) => {
    console.log(err);

    res.status(500).send('Internal Server Error!');
  });
})
router.get('/:id', (req, res) => {
  Product.findById(req.params.id).then((product) => {
    if (product) {
      res.json(product)
    } else {
      res.status(404).send('Product not found');
    }
  }).catch((err) => {
    res.status(500).send('Internal Server Error!');
  });
})



router.put('/:id', (req, res) => {
  Product.findOneAndUpdate(req.params.id, req.body).then((product) => {
    if (product) {
      res.status(200).json('Product updated Successfully!')

    } else {
      res.status(404).send('Product Not found!');
    }
  }).catch((err) => {
    res.status(500).send('Internal Server Error!');
  });
});

router.delete('/:id', (req, res) => {
  Product.findOneAndRemove(req.params.id).then((product) => {
    if (product) {

      res.json('Product deleted Successfully!')


    } else {
      res.status(404).send('Product Not found!');
    }
  }).catch((err) => {
    res.status(500).send('Internal Server Error!');
  });
});

module.exports = router;
