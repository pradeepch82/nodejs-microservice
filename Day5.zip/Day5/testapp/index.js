const express=require("express");

//create a server
var app = express();

//to read data 
app.use(express.json());
console.log("Environement variables :");
console.log(process.env);

app.get("/", (request, response) => {
    console.log("In Default mapping dddd");
    response.send("Express Monitoring Application New"+process.env.pm_id);
});

app.get("/add/:a/:b", (request, response) => {
    let a=parseInt(request.params.a);
    let b=parseInt(request.params.b);
    let sum=a+b;    
    response.send("Addition is :"+sum)}
);
    


app.listen(3000,console.log("Express App started on port 3000"));

