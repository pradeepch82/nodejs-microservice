var express=require("express");
var dotenv=require("dotenv");
dotenv.config();


port=process.env.PORT;
appName=process.env.name;

console.log("PORT    :"+port);
console.log("appName :"+appName);


var app=express();

app.get("/",(req,res)=>res.send("Hello World  "+appName));
app.listen(port,()=>` ${appName}  listening on port ${port}`);