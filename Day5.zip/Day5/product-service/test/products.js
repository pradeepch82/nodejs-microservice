var chai=require("chai");
var chaiHttp=require("chai-http");
var should=chai.should();
chai.use(chaiHttp);

describe("Store App - Product Service",()=>{

beforeEach((done)=>{  console.log("------Before Each-----"); 
done();
})

afterEach((done)=>{  console.log("------After Each-----"); 
done();
})


//Test  GET routes for /products
describe("Testing   /products -  GET  route ",()=>{

 it("It should return array of 2 products",(done)=>{


chai.request("http://localhost:4545")
            .get("/products")
            .end((err,response)=>{
                response.should.have.status(200);
                response.body.should.be.a('array');
                response.body.length.should.be.eql(2);
                done();
            });
          });
});


//Test  GET routes for /products
describe("Testing   /products/:id -  GET  route ",()=>{

    it("It should return array of 2 products",(done)=>{
   
   
   chai.request("http://localhost:4545")
               .get("/products")
               .end((err,response)=>{
                   response.should.have.status(200);
                   response.body.should.be.a('array');
                   response.body.length.should.be.eql(2);
                   done();
               });
             });
   });
   

});

