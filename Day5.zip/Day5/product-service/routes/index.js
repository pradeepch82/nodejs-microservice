var express = require('express');
var router = express.Router();

/* GET home page. */

var port = process.env.PORT;

router.get('/', function(req, res, next) {
  res.render('index', { title: 'Product Application running on port :'+port});
});

module.exports = router;
