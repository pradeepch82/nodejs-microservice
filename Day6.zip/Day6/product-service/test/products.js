var chai=require("chai");
var chaiHttp=require("chai-http");
var should=chai.should();
chai.use(chaiHttp);





//Test Suite
describe("Store App - Product Service",function (){
    this.retries(2);
before((done)=>{
    console.log("-------------Before All --------------");
    done();
});

after((done)=>{
    console.log("-------------After All --------------");
    done();
});


beforeEach((done)=>{  console.log("------Before Each-----"); 
done();
})

afterEach((done)=>{  console.log("------After Each-----"); 
done();
})


//Test Suite
describe("Store App - Test",()=>{

    describe("A Test",()=>{
      //  it.only(" Pending 1");
      //  it.only(" Pending 2");
        it(" Pending 3");
        it(" Pending 4");
    });

});








//Test  GET routes for /products
describe.skip("Testing   /products -  GET  route ",()=>{

   // it.skip("It is a pending test 1");
   // it.skip("It is a pending test 2" );
   // it("It is a pending test 3");
   // it("It is a pending test 4");
    
       


it("It should return 404 with message Products not Found",(done)=>{
   
       

   chai.request("http://localhost:4545")
               .get("/products")
               .end((err,response)=>{
                   response.should.have.status(404);
                   response.text.should.eql("Products not found");
                   done();
               });
             });
});


//Test  GET route for /products/:id
describe.skip("Testing   /products/:id -  GET  route ",()=>{
   
    it("It should return with status 500 with message  Internal Server Error",(done)=>{
    
   chai.request("http://localhost:4545")
               .get("/products/11")
               .end((err,response)=>{
                   response.text.should.eql('Internal Server Error!');
                   done();
               });
             });
   });
   



   //Test  PUT route for /products/:id
describe("Testing   /products/:id -  PUT  route ",()=>{

    it("It should return 404 with message Product Not found!",(done)=>{
    

    let product={"_id":"61a0ae5da0185ee7f5dfe973","name":"LG New _Updated","price":4444.44};


   chai.request("http://localhost:4545")
               .put("/products/11")
               .send(product)
               .end((err,response)=>{
                   response.should.have.status(404);
                   response.text.should.eql("Product Not found!");
                 done();
               });
             });
   });
   



//Test  DELETE route for /products/:id
describe("Testing   /products/:id -  DELETE  route ",()=>{
   
    it("It should return 404 with message Product Not found!",(done)=>{
    
   chai.request("http://localhost:4545")
               .delete("/products/11")
               .end((err,response)=>{
                   response.should.have.status(404);
                   response.text.should.eql("Product Not found!");
                               done();
               });
             });
   });


   

//=========================================================






//Test  POST route for /products/:id
describe("Testing   /products-  POST  route ",()=>{
   
    it("It should add  Product",(done)=>{


        let product={"_id":"61a0ae5da0185ee7f5dfe973","name":"LG","price":40000.44};

    
   chai.request("http://localhost:4545")
               .post("/products")
               .send(product)
               .end((err,response)=>{
                   response.should.have.status(201);
                   response.body.should.be.a('object');
                   response.body.should.have.property('_id');
                   response.body.should.have.property('name');
                   response.body.should.have.property('price'); 
                   done();
               });
             });
   });



//Test  GET routes for /products
describe("Testing   /products -  GET  route ",()=>{

 it("It should return array of  products",(done)=>{


chai.request("http://localhost:4545")
            .get("/products")
            .end((err,response)=>{
                response.should.have.status(200);
                response.body.should.be.a('array');
                response.body.length.should.be.eql(1);
                done();
            });
          });
});


   //Test  GET route for /products/:id
   describe("Testing   /products/:id -  GET  route ",()=>{
   
    it("It should return Product by id",(done)=>{
    
   chai.request("http://localhost:4545")
               .get("/products/61a0ae5da0185ee7f5dfe973")
               .end((err,response)=>{
                   response.should.have.status(200);
                   response.body.should.be.a('object');
                   response.body.should.have.property('_id');
                   response.body.should.have.property('name');
                   response.body.should.have.property('price');                                      
                   response.body.should.have.property('_id').eql('61a0ae5da0185ee7f5dfe973');
                   done();
               });
             });
   });
   

//Test  PUT route for /products/:id
describe("Testing   /products/:id -  PUT  route ",()=>{

    it("It should update Product by id",(done)=>{
    

    let product={"_id":"61a0ae5da0185ee7f5dfe973","name":"LG New _Updated","price":4444.44};


   chai.request("http://localhost:4545")
               .put("/products/61a0ae5da0185ee7f5dfe973")
               .send(product)
               .end((err,response)=>{
                   response.should.have.status(200);
                   response.body.should.eql("Product updated Successfully!");
                 
                   done();
               });
             });
   });
   



//Test  DELETE route for /products/:id
describe("Testing   /products/:id -  DELETE  route ",()=>{
   
    it("It should delete Product by id",(done)=>{
    
   chai.request("http://localhost:4545")
               .delete("/products/61a0ae5da0185ee7f5dfe973")
               .end((err,response)=>{
                   response.should.have.status(200);
                   response.body.should.eql("Product deleted Successfully!");
                 
                   done();
               });
             });
   });


});

