console.log("Welcome To JS");
console.log("Welcome To JS");
console.log("Welcome To JS");
console.log("Welcome To JS");
console.log("Welcome To JS");
document.bgColor="lightgreen";