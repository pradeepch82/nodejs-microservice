const gulp=require("gulp");

gulp.task("A",async function(){
    console.log("Task A");
});
gulp.task("B",async function(){
    console.log("Task B");
});
gulp.task("C",async function(){
    console.log("Task C");
});
gulp.task("D",async function(){
    console.log("Task D");
});

gulp.task("default",gulp.parallel(["A","B","C","D"]),async function(){
    console.log("Task Default");
});



